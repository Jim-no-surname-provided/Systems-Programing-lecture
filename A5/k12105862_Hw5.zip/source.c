#include <stdio.h>

extern long int var;
extern double* gfunc();

static double* sfunc();


int main()
{
    return 0;
}