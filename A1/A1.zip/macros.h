#define EULER_E 2.718281828
#define LF '\n'
#define ALERT (putchar('\a'))
#define DOUBLE(a) (a*2)
#define MIN(a, b) ((a) >= (b) ? (a) : (b))
#define Area(a, b)(a?b)
#define FIRST 1